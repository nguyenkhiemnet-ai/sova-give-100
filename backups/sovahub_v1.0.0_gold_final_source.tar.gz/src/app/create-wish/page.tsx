'use client';

import { useState, useEffect, useRef } from 'react';
import Link from 'next/link';
import { supabase } from '@/lib/supabaseClient';
import { VIETNAM_PROVINCES, getDistrictsByProvince, CATEGORY_FALLBACK_IMAGES } from '@/lib/provinces';
import { getFullSiteCMS, DEFAULT_FULL_CMS } from '@/lib/cms';
import { getActiveUser, openAuthModal } from '@/lib/auth';
import { 
  ArrowLeft, Sparkles, Laptop, Bike, Scissors, BookOpen, 
  Wrench, Camera, ShieldCheck, CheckCircle2, Heart, MapPin, 
  Check, Plus, Lock, User, Image as ImageIcon
} from 'lucide-react';

const CATEGORIES = [
  { id: 'bicycle', label: 'Xe đạp đến trường', desc: 'Phương tiện đi lại cho học sinh nghèo', icon: Bike },
  { id: 'laptop', label: 'Máy tính học tập', desc: 'Laptop, PC cho học sinh - sinh viên', icon: Laptop },
  { id: 'sewing_machine', label: 'Máy may sinh kế', desc: 'Dụng cụ may vá cho mẹ đơn thân', icon: Scissors },
  { id: 'study_tools', label: 'Dụng cụ tri thức', desc: 'Sách vở, bàn học, máy tính cầm tay', icon: BookOpen },
  { id: 'livelihood_tools', label: 'Công cụ mưu sinh', desc: 'Đồ nghề sửa xe, làm mộc, làm nông', icon: Wrench },
];

const DEFAULT_PLEDGES = [
  "Tôi cam kết giữ gìn thiết bị cẩn thận và trao lại cho người khác khi không còn dùng đến.",
  "Tôi cam kết dùng đúng mục đích học tập/sinh kế tự lập, không bán hay cầm cố.",
  "Tôi cam kết chia sẻ kinh nghiệm và hỗ trợ cộng đồng sau khi vượt qua khó khăn."
];

export default function CreateWishPage() {
  const [step, setStep] = useState(1);
  const [category, setCategory] = useState('bicycle');
  const [title, setTitle] = useState('');
  const [reason, setReason] = useState('');
  const [provinceCode, setProvinceCode] = useState('48');
  const [districtCode, setDistrictCode] = useState('48-ST');
  const [urgency, setUrgency] = useState('urgent');
  
  const [selectedPledges, setSelectedPledges] = useState<string[]>([DEFAULT_PLEDGES[0], DEFAULT_PLEDGES[1]]);
  const [customPledge, setCustomPledge] = useState('');
  const [enableCustom, setEnableCustom] = useState(false);

  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [imageSizeKb, setImageSizeKb] = useState<number | null>(null);
  const cameraInputRef = useRef<HTMLInputElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const [submitting, setSubmitting] = useState(false);
  const [createdPassport, setCreatedPassport] = useState<string | null>(null);
  const [subpageNotice, setSubpageNotice] = useState(DEFAULT_FULL_CMS.subpages.createWishNotice);
  const [currentUser, setCurrentUser] = useState<any>(null);

  useEffect(() => {
    setSubpageNotice(getFullSiteCMS().subpages.createWishNotice);
    const user = getActiveUser();
    setCurrentUser(user);
    if (!user) {
      openAuthModal('REGISTER');
    }

    const handleAuthChange = () => {
      setCurrentUser(getActiveUser());
    };
    window.addEventListener('sova_auth_change', handleAuthChange);
    return () => window.removeEventListener('sova_auth_change', handleAuthChange);
  }, []);

  // Tự động nhận diện danh mục theo từ khóa
  const handleTitleChange = (val: string) => {
    setTitle(val);
    const low = val.toLowerCase();
    if (low.includes('xe') || low.includes('đạp') || low.includes('dap') || low.includes('bike')) {
      setCategory('bicycle');
    } else if (low.includes('laptop') || low.includes('máy tính') || low.includes('pc')) {
      setCategory('laptop');
    } else if (low.includes('may') || low.includes('khâu')) {
      setCategory('sewing_machine');
    }
  };

  const togglePledge = (pledge: string) => {
    setSelectedPledges(prev => 
      prev.includes(pledge) ? prev.filter(p => p !== pledge) : [...prev, pledge]
    );
  };

  // Nén ảnh bảo toàn tỉ lệ khung hình gốc & ép dung lượng chuẩn 40KB - 75KB (< 80KB)
  const handleImageSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        const img = new Image();
        img.onload = () => {
          const canvas = document.createElement('canvas');
          const MAX_DIMENSION = 1200; // Cạnh lớn nhất tối đa 1200px
          let width = img.width;
          let height = img.height;

          if (width > height) {
            if (width > MAX_DIMENSION) {
              height = Math.round((height * MAX_DIMENSION) / width);
              width = MAX_DIMENSION;
            }
          } else {
            if (height > MAX_DIMENSION) {
              width = Math.round((width * MAX_DIMENSION) / height);
              height = MAX_DIMENSION;
            }
          }

          canvas.width = width;
          canvas.height = height;
          const ctx = canvas.getContext('2d');
          ctx?.drawImage(img, 0, 0, width, height);

          // Nén thông minh: tự động điều chỉnh chất lượng để kích thước luôn nằm trong khoảng 40KB - 75KB (< 80KB)
          let quality = 0.72;
          let compressed = canvas.toDataURL('image/jpeg', quality);

          // Nếu ảnh > 75KB (~102,000 ký tự Base64), giảm dần quality
          while (compressed.length > 102000 && quality > 0.28) {
            quality -= 0.08;
            compressed = canvas.toDataURL('image/jpeg', quality);
          }

          // Nếu vẫn > 75KB (ảnh chi tiết phức tạp), downscale nhẹ thêm 1 nấc
          if (compressed.length > 102000) {
            const downScale = 0.8;
            canvas.width = Math.round(width * downScale);
            canvas.height = Math.round(height * downScale);
            ctx?.drawImage(img, 0, 0, canvas.width, canvas.height);
            compressed = canvas.toDataURL('image/jpeg', 0.65);
          }

          const approxKb = Math.round((compressed.length * 3) / 4 / 1024);
          setImagePreview(compressed);
          setImageSizeKb(approxKb);
        };
        img.src = event.target?.result as string;
      };
      reader.readAsDataURL(file);
    }
    e.target.value = '';
  };
  const handleImageChange = handleImageSelect;

  const handleProvinceChange = (pCode: string) => {
    setProvinceCode(pCode);
    const districts = getDistrictsByProvince(pCode);
    if (districts.length > 0) {
      setDistrictCode(districts[0].code);
    }
  };

  const handleSubmit = async () => {
    const user = getActiveUser();
    if (!user) {
      openAuthModal('REGISTER');
      return;
    }

    if (!title.trim() || !reason.trim()) {
      alert('Vui lòng điền tiêu đề và chia sẻ hoàn cảnh của bạn.');
      return;
    }

    setSubmitting(true);
    const passportCode = `SOVA-PASS-${Math.floor(1000 + Math.random() * 9000)}-VN`;
    const finalCommitments = [...selectedPledges];
    if (enableCustom && customPledge.trim()) {
      finalCommitments.push(`Lời hứa từ trái tim: "${customPledge.trim()}"`);
    }
    const combinedPledge = finalCommitments.join(' | ');

    const chosenImage = imagePreview || CATEGORY_FALLBACK_IMAGES[category] || CATEGORY_FALLBACK_IMAGES['bicycle'];

    const newWish = {
      title: title.trim(),
      category,
      amount: 100,
      authority: user.email?.trim().toLowerCase() || user.id,
      reason: reason.trim(),
      honor_commitment: combinedPledge,
      urgency,
      province_code: provinceCode,
      ward_code: districtCode,
      status: 'pending'
    };

    try {
      const { data } = await supabase.from('wishes').insert([newWish]).select();
      const generatedId = (data && data[0]?.id) || 'opt-' + Date.now();
      
      const localItem = {
        id: generatedId,
        ...newWish,
        imageUrl: chosenImage,
        created_at: new Date().toISOString()
      };
      
      // Lưu ảnh độc lập theo ID để không bao giờ bị ghi đè
      localStorage.setItem(`SOVA_WISH_IMG_${generatedId}`, chosenImage);

      // Ghi nhận quyền sở hữu điều ước cho tài khoản hiện tại
      try {
        const userKey = `SOVA_MY_WISHES_${user.id}`;
        const emailKey = `SOVA_MY_WISHES_${user.email?.toLowerCase()}`;
        const curUserIds = JSON.parse(localStorage.getItem(userKey) || '[]');
        if (!curUserIds.includes(generatedId)) curUserIds.push(generatedId);
        localStorage.setItem(userKey, JSON.stringify(curUserIds));
        localStorage.setItem(emailKey, JSON.stringify(curUserIds));
      } catch {}
      
      const stored = localStorage.getItem('SOVA_OPTIMISTIC_WISHES');
      const list = stored ? JSON.parse(stored) : [];
      localStorage.setItem('SOVA_OPTIMISTIC_WISHES', JSON.stringify([localItem, ...list]));

      setCreatedPassport(passportCode);
    } catch {
      setCreatedPassport(passportCode);
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="space-y-8 max-w-3xl mx-auto pb-28 sm:pb-32">
      <div className="flex items-center justify-between">
        <Link 
          href="/" 
          className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl border border-warm-200 bg-white text-xs font-bold text-warm-700 hover:text-brand-700 shadow-2xs transition-all"
        >
          <ArrowLeft className="w-4 h-4"/>
          <span>Quay lại Cây Nguyện Ước</span>
        </Link>
        <span className="text-[11px] font-bold text-warm-700 hidden sm:inline">{subpageNotice}</span>
      </div>

      <div className="bg-white rounded-3xl border border-warm-200 p-6 sm:p-10 shadow-soft space-y-8">
        
        {!currentUser && (
          <div className="p-4 bg-brand-50 border-2 border-brand-500 rounded-2xl flex flex-col sm:flex-row items-center justify-between gap-3 text-center sm:text-left shadow-soft">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-brand-600 text-white flex items-center justify-center shrink-0 shadow-2xs">
                <Lock className="w-5 h-5"/>
              </div>
              <div>
                <h4 className="text-xs font-black text-warm-900">Yêu cầu đăng ký tài khoản trước khi gửi ước nguyện</h4>
                <p className="text-[11px] text-warm-600">Đăng ký hoàn toàn 0-VND để quản lý hồ sơ và nhận thông báo khi có Angel tiếp sức.</p>
              </div>
            </div>
            <button
              onClick={() => openAuthModal('REGISTER')}
              className="px-4 py-2 rounded-xl bg-brand-600 hover:bg-brand-700 text-white font-black text-xs shadow-xs hover:scale-105 transition-all shrink-0 cursor-pointer"
            >
              Tạo tài khoản ngay
            </button>
          </div>
        )}

        {/* Progress Bar */}
        <div className="flex items-center justify-between border-b border-warm-200 pb-5">
          <div className="flex items-center gap-2">
            <div className={`w-7 h-7 rounded-full flex items-center justify-center text-xs font-black ${
              step >= 1 ? 'bg-brand-600 text-white' : 'bg-warm-100 text-warm-700'
            }`}>1</div>
            <span className="text-xs font-bold text-warm-900">Nhu Cầu</span>
          </div>
          <div className="h-0.5 flex-1 mx-4 bg-warm-100">
            <div className={`h-full bg-brand-600 transition-all ${step === 1 ? 'w-0' : step === 2 ? 'w-1/2' : 'w-full'}`}/>
          </div>
          <div className="flex items-center gap-2">
            <div className={`w-7 h-7 rounded-full flex items-center justify-center text-xs font-black ${
              step >= 2 ? 'bg-brand-600 text-white' : 'bg-warm-100 text-warm-700'
            }`}>2</div>
            <span className="text-xs font-bold text-warm-900">Hình Ảnh</span>
          </div>
          <div className="h-0.5 flex-1 mx-4 bg-warm-100">
            <div className={`h-full bg-brand-600 transition-all ${step <= 2 ? 'w-0' : 'w-full'}`}/>
          </div>
          <div className="flex items-center gap-2">
            <div className={`w-7 h-7 rounded-full flex items-center justify-center text-xs font-black ${
              step >= 3 ? 'bg-brand-600 text-white' : 'bg-warm-100 text-warm-700'
            }`}>3</div>
            <span className="text-xs font-bold text-warm-900">Cam Kết & Địa Bàn</span>
          </div>
        </div>

        {/* BƯỚC 1: CHỌN NHU CẦU */}
        {step === 1 && (
          <div className="space-y-6">
            <div>
              <h2 className="text-xl font-black text-warm-900">Bạn đang cần dụng cụ nào để tiếp sức sinh kế / học tập?</h2>
              <p className="text-xs text-warm-700 mt-1">Chọn đúng nhóm dụng cụ để hệ thống phân loại đến nhà hảo tâm.</p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
              {CATEGORIES.map(cat => {
                const Icon = cat.icon;
                const active = category === cat.id;
                return (
                  <button
                    key={cat.id}
                    type="button"
                    onClick={() => {
                      setCategory(cat.id);
                      if (!title) setTitle(cat.label);
                      setTimeout(() => {
                        setStep(2);
                        window.scrollTo({ top: 0, behavior: 'smooth' });
                      }, 300);
                    }}
                    className={`p-4 rounded-2xl border-2 text-left flex items-start gap-3.5 transition-all cursor-pointer ${
                      active 
                        ? 'border-brand-600 bg-brand-50/60 shadow-soft ring-2 ring-brand-500 scale-[1.01]' 
                        : 'border-warm-200 hover:border-brand-300 hover:bg-warm-50/50 bg-white'
                    }`}
                  >
                    <div className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 transition-colors ${
                      active ? 'bg-brand-600 text-white shadow-2xs' : 'bg-warm-100 text-warm-700'
                    }`}>
                      <Icon className="w-5 h-5"/>
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center justify-between">
                        <h4 className="font-black text-sm text-warm-900">{cat.label}</h4>
                        {active && (
                          <span className="text-[10px] font-bold text-brand-700 bg-brand-100 px-2 py-0.5 rounded-full animate-pulse">
                            Đã chọn
                          </span>
                        )}
                      </div>
                      <p className="text-[11px] text-warm-700 mt-0.5">{cat.desc}</p>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>
        )}

        {/* BƯỚC 2: HÌNH ẢNH */}
        {step === 2 && (
          <div className="space-y-6">
            <div>
              <div className="flex items-center gap-2 text-brand-700 text-xs font-black uppercase">
                <ShieldCheck className="w-4 h-4 text-brand-600"/>
                Hình Ảnh Minh Chứng (Dignity Shield)
              </div>
              <p className="text-xs text-warm-700 mt-1">
                Tải ảnh phương tiện hoặc đồ dùng bạn cần để người trao hình dung rõ nhất.
              </p>
            </div>

            <div className="border-2 border-dashed border-warm-200 rounded-3xl p-8 text-center space-y-4 hover:border-brand-500 transition-colors bg-warm-50/50">
              {/* Input 1 (Camera trực tiếp): capture="environment" */}
              <input
                ref={cameraInputRef}
                type="file"
                accept="image/*"
                capture="environment"
                className="hidden"
                onChange={handleImageSelect}
              />
              {/* Input 2 (Thư viện máy) */}
              <input
                ref={fileInputRef}
                type="file"
                accept="image/*"
                className="hidden"
                onChange={handleImageSelect}
              />

              {imagePreview ? (
                <div className="relative inline-block max-w-full">
                  <div className="p-2 bg-warm-100/70 rounded-2xl border border-warm-200 shadow-inner">
                    <img 
                      src={imagePreview} 
                      alt="Preview" 
                      className="max-h-72 sm:max-h-80 w-auto max-w-full rounded-xl shadow-xs mx-auto object-contain"
                    />
                  </div>

                  <div className="mt-3 flex items-center justify-center gap-2">
                    <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-50 border border-emerald-300 text-emerald-800 text-[11px] font-bold shadow-2xs">
                      <ShieldCheck className="w-3.5 h-3.5 text-emerald-600"/>
                      <span>Dung lượng chuẩn: ~{imageSizeKb || 55} KB (&lt; 80KB) • Tỉ lệ gốc 100%</span>
                    </span>
                  </div>

                  <button
                    type="button"
                    onClick={() => {
                      setImagePreview(null);
                      setImageSizeKb(null);
                    }}
                    className="absolute -top-2 -right-2 w-8 h-8 bg-red-600 hover:bg-red-700 text-white rounded-full text-xs font-bold shadow-md flex items-center justify-center transition-transform hover:scale-110 cursor-pointer"
                    title="Xóa ảnh để chọn lại"
                  >
                    ✕
                  </button>
                </div>
              ) : (
                <div className="space-y-4 max-w-md mx-auto">
                  <div className="w-14 h-14 rounded-2xl bg-brand-50 text-brand-600 mx-auto flex items-center justify-center shadow-2xs">
                    <Camera className="w-7 h-7"/>
                  </div>
                  <div>
                    <p className="text-xs font-black text-warm-900">Chụp hoặc tải ảnh phương tiện bạn mong muốn</p>
                    <p className="text-[11px] text-warm-700 mt-0.5">Hệ thống sẽ tự động tối ưu hóa kích thước ảnh bảo đảm tải siêu tốc.</p>
                  </div>
                  
                  {/* Cụm 2 nút bấm: Nằm ngang trên máy tính (sm:flex-row), xếp dọc trên điện thoại (flex-col) */}
                  <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-center gap-3 pt-2">
                    <button
                      type="button"
                      onClick={() => cameraInputRef.current?.click()}
                      className="px-5 py-3 rounded-2xl bg-brand-600 hover:bg-brand-700 active:scale-95 text-white text-xs font-black shadow-md shadow-brand-600/20 hover:shadow-brand-600/30 flex items-center justify-center gap-2 transition-all cursor-pointer border border-brand-500"
                    >
                      <Camera className="w-4 h-4"/>
                      <span>📸 Chụp Ảnh Ngay</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => fileInputRef.current?.click()}
                      className="px-5 py-3 rounded-2xl bg-white hover:bg-brand-50 active:scale-95 text-brand-800 text-xs font-black border-2 border-brand-200 hover:border-brand-500 shadow-xs flex items-center justify-center gap-2 transition-all cursor-pointer"
                    >
                      <ImageIcon className="w-4 h-4 text-brand-600"/>
                      <span>🖼️ Chọn Từ Thư Viện</span>
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>
        )}

        {/* BƯỚC 3: LỜI NGỎ, CAM KẾT & ĐỊA BÀN */}
        {step === 3 && (
          <div className="space-y-6">
            <div className="space-y-4">
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-warm-800">Tiêu đề ngắn gọn:</label>
                <input
                  type="text"
                  placeholder="Ví dụ: Xe đạp đến trường cho học sinh lớp 10..."
                  value={title}
                  onChange={e => handleTitleChange(e.target.value)}
                  className="w-full p-3 rounded-2xl border-2 border-warm-200 text-xs font-bold text-warm-900 focus:border-brand-600 focus:outline-none"
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-bold text-warm-800">Chia sẻ chân thực về hoàn cảnh & mục tiêu sử dụng:</label>
                <textarea
                  rows={3}
                  placeholder="Nói rõ hoàn cảnh gia đình, chiều cao của người nhận hoặc cấu hình mong muốn..."
                  value={reason}
                  onChange={e => setReason(e.target.value)}
                  className="w-full p-3 rounded-2xl border-2 border-warm-200 text-xs font-medium text-warm-900 focus:border-brand-600 focus:outline-none"
                />
              </div>
            </div>

            {/* CHECKLIST CAM KẾT DANH DỰ */}
            <div className="space-y-2.5 pt-2">
              <label className="text-xs font-black text-warm-900 flex items-center gap-1.5">
                <Heart className="w-4 h-4 text-brand-600 fill-brand-600"/>
                <span>Chọn Các Lời Cam Kết Danh Dự Của Bạn:</span>
              </label>

              <div className="space-y-2">
                {DEFAULT_PLEDGES.map((pledge, idx) => {
                  const isChecked = selectedPledges.includes(pledge);
                  return (
                    <div
                      key={idx}
                      onClick={() => togglePledge(pledge)}
                      className={`p-3 rounded-2xl border-2 flex items-start gap-3 cursor-pointer transition-all ${
                        isChecked ? 'border-brand-600 bg-brand-50/50 shadow-2xs' : 'border-warm-200 bg-white'
                      }`}
                    >
                      <div className={`w-5 h-5 rounded-lg border-2 flex items-center justify-center shrink-0 mt-0.5 ${
                        isChecked ? 'bg-brand-600 border-brand-600 text-white' : 'border-warm-300'
                      }`}>
                        {isChecked && <Check className="w-3.5 h-3.5"/>}
                      </div>
                      <p className="text-xs font-bold text-warm-900 leading-relaxed">"{pledge}"</p>
                    </div>
                  );
                })}
              </div>

              <div className="pt-2">
                <button
                  type="button"
                  onClick={() => setEnableCustom(!enableCustom)}
                  className="inline-flex items-center gap-1.5 text-xs font-black text-brand-700"
                >
                  <Plus className="w-4 h-4"/>
                  <span>{enableCustom ? 'Thu gọn cam kết riêng' : '+ Tự viết thêm lời hứa từ trái tim'}</span>
                </button>

                {enableCustom && (
                  <textarea
                    rows={2}
                    placeholder="Viết lời hứa danh dự của riêng bạn..."
                    value={customPledge}
                    onChange={e => setCustomPledge(e.target.value)}
                    className="mt-2 w-full p-3 rounded-2xl border-2 border-brand-300 bg-brand-50/30 text-xs font-medium text-warm-900 focus:outline-none focus:border-brand-600"
                  />
                )}
              </div>
            </div>

            {/* CHỌN ĐỊA BÀN PHÂN CẤP */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-warm-800 flex items-center gap-1">
                  <MapPin className="w-3.5 h-3.5 text-brand-600"/>
                  <span>Tỉnh / Thành phố:</span>
                </label>
                <select
                  value={provinceCode}
                  onChange={e => handleProvinceChange(e.target.value)}
                  className="w-full p-3 rounded-2xl border-2 border-warm-200 text-xs font-black text-warm-900 bg-white focus:border-brand-600 focus:outline-none"
                >
                  {VIETNAM_PROVINCES.map(p => (
                    <option key={p.code} value={p.code}>{p.name}</option>
                  ))}
                </select>
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-bold text-warm-800">Quận / Huyện cụ thể:</label>
                <select
                  value={districtCode}
                  onChange={e => setDistrictCode(e.target.value)}
                  className="w-full p-3 rounded-2xl border-2 border-warm-200 text-xs font-bold text-warm-900 bg-white focus:border-brand-600 focus:outline-none"
                >
                  {getDistrictsByProvince(provinceCode).map(d => (
                    <option key={d.code} value={d.code}>{d.name}</option>
                  ))}
                </select>
              </div>
            </div>
          </div>
        )}

      </div>

      {/* FLOATING ACTION DOCK (6-STAR ERGONOMIC EXPERIENCE) */}
      <div className="fixed bottom-0 left-0 right-0 z-[60] bg-white/95 dark:bg-slate-900/95 backdrop-blur-md border-t border-emerald-500/30 px-4 py-3 shadow-[0_-8px_30px_rgba(0,0,0,0.12)]">
        <div className="max-w-3xl mx-auto flex items-center justify-between gap-3">
          {/* Nút Quay Lại */}
          {step > 1 ? (
            <button
              type="button"
              onClick={() => {
                setStep(step - 1);
                window.scrollTo({ top: 0, behavior: 'smooth' });
              }}
              className="px-4 sm:px-5 py-2.5 rounded-xl border border-warm-200 bg-white hover:bg-warm-50 text-xs font-bold text-warm-700 hover:text-brand-700 shadow-2xs flex items-center gap-1.5 transition-all cursor-pointer"
            >
              <ArrowLeft className="w-4 h-4"/>
              <span>Quay Lại</span>
            </button>
          ) : (
            <div className="text-[11px] font-bold text-warm-600 hidden sm:flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-brand-500 animate-pulse" />
              <span>Bước 1/3: Chọn nhóm dụng cụ</span>
            </div>
          )}

          {/* Cụm Nút Hành Động Trọng Tâm */}
          <div className="flex items-center gap-2 ml-auto">
            {step === 1 && (
              <button
                type="button"
                onClick={() => {
                  setStep(2);
                  window.scrollTo({ top: 0, behavior: 'smooth' });
                }}
                className="px-6 py-3 rounded-2xl bg-brand-600 hover:bg-brand-700 active:scale-95 text-white text-xs font-black shadow-float flex items-center gap-2 transition-all cursor-pointer"
              >
                <span>Tiếp Tục Bước 2: Hình Ảnh</span>
                <Sparkles className="w-4 h-4"/>
              </button>
            )}

            {step === 2 && (
              <button
                type="button"
                onClick={() => {
                  setStep(3);
                  window.scrollTo({ top: 0, behavior: 'smooth' });
                }}
                className="px-6 py-3 rounded-2xl bg-brand-600 hover:bg-brand-700 active:scale-95 text-white text-xs font-black shadow-float flex items-center gap-2 transition-all cursor-pointer"
              >
                <span>Tiếp Tục Bước 3: Cam Kết</span>
                <Sparkles className="w-4 h-4"/>
              </button>
            )}

            {step === 3 && (
              <button
                type="button"
                disabled={submitting}
                onClick={handleSubmit}
                className="px-6 sm:px-8 py-3.5 rounded-2xl bg-brand-600 hover:bg-brand-700 active:scale-95 text-white text-xs font-black shadow-float disabled:opacity-50 flex items-center gap-2 transition-all cursor-pointer"
              >
                <Sparkles className="w-4 h-4"/>
                <span>{submitting ? 'Đang Gieo Mầm...' : 'Gieo Mầm Ước Nguyện 0-VND'}</span>
              </button>
            )}
          </div>
        </div>
      </div>

      {/* MODAL THÀNH CÔNG */}
      {createdPassport && (
        <div className="fixed inset-0 z-50 bg-warm-900/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl border-2 border-brand-500 max-w-md w-full p-6 sm:p-8 shadow-2xl text-center space-y-5">
            <div className="w-16 h-16 rounded-full bg-brand-50 text-brand-600 mx-auto flex items-center justify-center ring-8 ring-brand-100">
              <CheckCircle2 className="w-9 h-9"/>
            </div>
            <div className="space-y-2">
              <span className="px-3 py-1 rounded-full bg-brand-100 text-brand-800 text-[10px] font-black uppercase">
                Gieo Mầm Thành Công 100%
              </span>
              <h3 className="text-xl font-black text-warm-900">Ước Nguyện Đã Lên Cây!</h3>
              <p className="text-xs text-warm-700 leading-relaxed">
                Mã Hộ Chiếu Số: <strong className="font-mono text-brand-700 text-sm block mt-1">{createdPassport}</strong>
              </p>
            </div>
            <div className="pt-2">
              <Link href="/" className="w-full py-3 rounded-2xl bg-brand-600 hover:bg-brand-700 text-white text-xs font-black shadow-float block">
                Xem Ngay Trên Cây Nguyện Ước
              </Link>
            </div>
          </div>
        </div>
      )}

    </div>
  );
}
