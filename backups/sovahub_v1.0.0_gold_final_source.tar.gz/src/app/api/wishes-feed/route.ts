import { NextResponse } from 'next/server';
import { supabase } from '@/lib/supabaseClient';

export async function GET(request: Request) {
  try {
    // 1. Chỉ chọn các trường cần thiết phục vụ Feed để tối ưu hóa Egress (< 5KB payload)
    const { data, error } = await supabase
      .from('wishes')
      .select('id, title, category, reason, honor_commitment, urgency, province_code, ward_code, status, created_at, authority')
      .neq('status', 'archived')
      .order('created_at', { ascending: false })
      .limit(100);

    if (error) {
      console.warn('Lỗi truy vấn wishes feed từ Supabase:', error.message);
      return NextResponse.json({ success: false, data: [] }, {
        status: 200,
        headers: {
          'Cache-Control': 'public, s-maxage=10, stale-while-revalidate=60',
          'Content-Type': 'application/json'
        }
      });
    }

    const isTestWish = (w: any) => {
      const title = (w.title || '').toLowerCase();
      const reason = (w.reason || '').toLowerCase();
      return title.includes('thử nghiệm') || 
             title.includes('test wish') || 
             title.includes('kiểm thử') || 
             title.includes('kiểm tra gửi') || 
             reason.includes('máy m3') ||
             w.id === '5d141b76-93d3-4a9f-82f4-deb816b5b946' ||
             w.id === '0160532f-7480-4e73-8c95-e3df6839a897' || 
             w.id === 'db4739ed-9ef1-4766-ba78-721a0648d679';
    };

    const cleanData = (data || []).filter(item => !isTestWish(item) && item.status !== 'archived');

    // 2. Trả về payload kèm Edge CDN Caching Headers
    // s-maxage=30: Cloudflare Edge lưu cache 30s
    // stale-while-revalidate=300: Phục vụ ngay dữ liệu đệm cũ trong khi tái tạo nền
    return NextResponse.json({ success: true, data: cleanData }, {
      status: 200,
      headers: {
        'Cache-Control': 'public, max-age=30, s-maxage=120, stale-while-revalidate=600',
        'CDN-Cache-Control': 'max-age=120, stale-while-revalidate=600',
        'Cloudflare-CDN-Cache-Control': 'max-age=120, stale-while-revalidate=600',
        'Content-Type': 'application/json'
      }
    });
  } catch (err: any) {
    return NextResponse.json({ success: false, error: err.message || 'Lỗi tải feed' }, { status: 500 });
  }
}

export async function POST(request: Request) {
  return NextResponse.json({ success: true, message: 'Wishes feed dynamic endpoint' });
}
